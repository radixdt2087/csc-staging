<?php
/***************************************************************************
 *                                                                          *
 *   (c) 2004 Vladimir V. Kalynyak, Alexey V. Vinokurov, Ilya M. Shalnev    *
 *                                                                          *
 * This  is  commercial  software,  only  users  who have purchased a valid *
 * license  and  accept  to the terms of the  License Agreement can install *
 * and use this program.                                                    *
 *                                                                          *
 ****************************************************************************
 * PLEASE READ THE FULL TEXT  OF THE SOFTWARE  LICENSE   AGREEMENT  IN  THE *
 * "copyright.txt" FILE PROVIDED WITH THIS DISTRIBUTION PACKAGE.            *
 ****************************************************************************/

use Tygh\Registry;

if (!defined('BOOTSTRAP')) { die('Access denied'); }

if (defined('PAYMENT_NOTIFICATION')) {
    if (isset($_REQUEST['order_id'])) {
        if ($mode == 'response') {
            $order_id = $_REQUEST['order_id'];            
            fn_change_order_status($order_id, $pp_response['order_status'], '', false);
            fn_finish_payment($order_id, $pp_response);
            fn_order_placement_routines('route', $order_id, false);
        }
    }       
    exit;
} else {     
    $apiKey = Registry::get('addons.digitzs_connect.api_key');
    if (!empty($apiKey)
        && !empty($order_info['payment_info']['card_number'])
        && !empty($order_info['payment_info']['cvv2'])
    ) {            
        try {      
            $ccount=0;
            $token=generateToken($apiKey);
            $token=$token->data->attributes->appToken;            
            if(count($order_info['product_groups']) > 1) {
                $ccount=1;
            }
            foreach ($order_info['product_groups'] as $key => $value) {                
                $subtotal = $value['package_info']['C'];      
                $error_status=false;    
                $current_id = $value['company_id'];
                $cdata = fn_get_company_data($current_id); 
                $vendor_merchant_id = '';
                if(!empty($cdata['digitzs_connect_account_id'])) {
                    $vendor_merchant_id = $cdata['digitzs_connect_account_id'];
                }
                $payment='';        
                if($vendor_merchant_id!='') {              
                    $payment_data=array('company_id'=>$current_id,'vendor_merchant_id'=>$vendor_merchant_id,'order_id'=>$order_info['order_id'],'payment_info'=>$order_info['payment_info'],'total'=>$subtotal,'currency'=>$order_info['payment_method']['processor_params']['currency'],'invoice_id'=>strval(mt_rand()));  
                    $order_data=getPaymentDetails($payment_data); 

                    $payment=createSplitPayment($order_data,$token);          
                    if(isset($payment->errors)) {
                        foreach($payment->errors as $mer) {                       
                            fn_set_notification('E', __('error'), $mer->detail);                           
                            $error_status=true;                 
                        }
                    }                     
                } else {
                    fn_set_notification('E', __('error'), $cdata['company'].' Not register with Digitzs Payment');                
                    $error_status=true;                                    
                }
                                
                if($error_status) {
                    fn_redirect('checkout.checkout');
                }
               
                if($payment->data->attributes->transaction->message == 'Success') {    
                    $pp_response['order_status'] = 'P';   
                    $_user_id=$order_info['user_id'];
                    $card_number=$order_info['payment_info']['card_number'];      
                    if($order_info['payment_info']['card_numbers']!='') {                
                        $card_number = strpos($order_info['payment_info']['card_number'],"X") >= 0 ? $order_info['payment_info']['card_numbers']:$order_info['payment_info']['card_number'];
                    }
                    $_user_data = array('card_holder_name'=>$order_info['payment_info']['cardholder_name'],
                    'card_number'=>$card_number,
                    'valid_thru'=>$order_info['payment_info']['expiry_month']."/".$order_info['payment_info']['expiry_year']);
                    db_query("UPDATE ?:users SET ?u WHERE user_id = ?i", $_user_data, $_user_id);                      
                    
                    $_data = array('commission_amount'=>$order_data['data']['attributes']['split']['amount']/100,'marketplace_profit'=>$order_data['data']['attributes']['split']['amount']/100);                                       
                    db_query("UPDATE ?:vendor_payouts SET ?u WHERE order_id = ?i", $_data,$payment_data['order_id'] + $ccount);
                    $ccount++;             
                } 
            }
        } catch (Exception $e) {
            fn_set_notification('E', __('error'), $e->getMessage());                
            $pp_response['reason_text'] = $e->getMessage();
            $pp_response['order_status'] = 'F';
        }
    } else {
        $pp_response['order_status'] = 'F';
    }

}

function generateToken($apiKey) {
    $appKey = 'V5Y10mcDeotpPUJ5xVd4L4Isi8ra0xfeLo3Z0uqaZREHYUIatuinXaJ4Q5Bngh6g';        
    $tokenApi = 'auth/token';
    $post = array(
      'data' => array('type' =>'auth','attributes' => array('appKey'=>$appKey))            
    );
    $post = json_encode($post);
    $header = array(
      "x-api-key:".$apiKey,
      "Content-Type: application/json"
    );
    return callDigitzApi($tokenApi,$post,$header);
}

function getPaymentDetails($order_info) {
    
    $merchant_id = Registry::get('addons.digitzs_connect.admin_merchant_id');
    $order_id=$order_info['order_id'];
    $payment_info=$order_info['payment_info'];
    $total = $order_info['total'];   
    $split_amount = calculateSplit($total);
    $vendor_commission = calculateCommision($order_info['company_id']); 
    $commission = ($total * $vendor_commission['commission'])/100;
    $commission += $vendor_commission['fixed_commission'];        
    $card_number=$order_info['payment_info']['card_number'];      
    if($order_info['payment_info']['card_numbers']!='') {                
        $card_number = strpos($order_info['payment_info']['card_number'],"X") >= 0 ? $order_info['payment_info']['card_numbers']:$order_info['payment_info']['card_number'];
    }    
    $paymentData = array("data" => array(      
      "type" => "payments",
      "attributes" => array(
          "paymentType" => "cardSplit",
          "merchantId" => $order_info['vendor_merchant_id'],
          "card" => array(
              "holder" => $payment_info['cardholder_name'],
              "number" => $card_number,
              "expiry" => $payment_info['expiry_month'].$payment_info['expiry_year'],
              "code" => $payment_info['cvv2']
          ),
          "split"=>array(
              "merchantId" =>$merchant_id,
              "amount" => strval(round($commission*100))
          ),
          "transaction" => array(
              "amount" => strval(round($split_amount*100)),
              "currency" =>$order_info['currency'],
              "invoice" => $order_info['invoice_id']
          )
        )
      )
    );
    return $paymentData;
}
function calculateCommision($company_id){
    $commission = db_get_row(
    'SELECT commission, fixed_commission'
    . ' FROM ?:vendor_plans AS p'
    . ' INNER JOIN ?:companies AS c ON c.plan_id = p.plan_id'
    . ' WHERE company_id = ?i', $company_id
    );
    return $commission;
}

function calculateSplit($total){ 
    $commissionfee = (2.9/100)*$total;
    $cardfee = $commissionfee + 0.30;
    $split_amt = $total - $cardfee; 
    return $split_amt;
}
function createSplitPayment($post,$token) {    
    $api = 'payments';
    $post = json_encode($post);
    $apiKey = Registry::get('addons.digitzs_connect.api_key');  
    $header=array(
      "Authorization:Bearer ".$token,
      "x-api-key:".$apiKey,
      "Content-Type:application/json"
    );
    return callDigitzApi($api,$post,$header);
  }
  function callDigitzApi($api,$post,$header) {
    $curl = curl_init();
    $modes = Registry::get('addons.digitzs_connect.modes');
    $endPoint = '';    
    
    if($modes =="Test") {
      $endPoint = "https://test.digitzsapi.com/test/";
    } else {
      $endPoint = "https://test.digitzsapi.com/test/";
    }
  
    curl_setopt_array($curl, array(
      CURLOPT_URL => $endPoint.$api,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => $post,
      CURLOPT_HTTPHEADER => $header,
    ));
    $response = curl_exec($curl);   
    curl_close($curl);
    return json_decode($response);  
  }  